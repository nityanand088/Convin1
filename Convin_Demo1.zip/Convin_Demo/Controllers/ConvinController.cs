﻿using Convin_Demo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Convin_Demo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConvinController : ControllerBase
    {
        [HttpPost("users")]
        public async Task<IActionResult> CreateUser([FromBody] CreateUserDto userDto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var user = new User
            {
                Email = userDto.Email,
                Name = userDto.Name,
                Mobile = userDto.Mobile
            };

            return Ok(user);
        }
        [HttpGet("users/{id}")]
        public async Task<IActionResult> GetUser(int id)
        {

        }

        [HttpPost("expenses")]
        public async Task<IActionResult> AddExpense([FromBody] AddExpenseDto expenseDto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var expense = new Expense
            {
                TotalAmount = expenseDto.Amount,
                SplitMethod = expenseDto.SplitMethod,
                PaidBy = expenseDto.PaidBy,
            };
            foreach (var participantDto in expenseDto.Participants)
            {
                var participant = new Participant
                {
                    UserId = participantDto.UserId,
                    Expense = expense,
                    Amount = participantDto.Amount,
                    Percentage = participantDto.Percentage
                };
            }

            return Ok(expense);
        }
        [HttpGet("users/{id}/expenses")]
        public async Task<IActionResult> GetUserExpenses(int id)
        {

        }
        [HttpGet("expenses")]
        public async Task<IActionResult> GetAllExpenses()
        {

        }
        [HttpGet("users/{id}/balance-sheet")]
        public async Task<IActionResult> DownloadBalanceSheet(int id)
        {

        }







    }
}
