﻿using System.ComponentModel.DataAnnotations;

namespace Convin_Demo.Models
{
    public class AddExpenseDto
    {
        [Required]
        public decimal Amount { get; set; }

        [Required]
        public string? SplitMethod { get; set; } 

        [Required]
        public int PaidBy { get; set; } 

        public List<ParticipantDto>? Participants { get; set; } 
    }

    public class ParticipantDto
    {
        [Required]
        public int UserId { get; set; }
            
        public decimal? Amount { get; set; } 
        public decimal? Percentage { get; set; } 
    }

}
