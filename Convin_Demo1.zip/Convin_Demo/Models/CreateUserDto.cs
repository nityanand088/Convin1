﻿using System.ComponentModel.DataAnnotations;

namespace Convin_Demo.Models
{
    public class CreateUserDto  
    {
        [Required]
        [EmailAddress]
        public string? Email { get; set; }

        [Required]
        public string? Name { get; set; }

        [Required]
        [Phone]
        public string? Mobile { get; set; }
    }

}
