﻿namespace Convin_Demo.Models
{
    public class Expense
    {
        public int Id { get; set; }
        public decimal TotalAmount { get; set; }
        public string SplitMethod { get; set; }
        public int PaidBy { get; set; }
        public User Payer { get; set; }
        public ICollection<Participant> Participants { get; set; }
    }

}
