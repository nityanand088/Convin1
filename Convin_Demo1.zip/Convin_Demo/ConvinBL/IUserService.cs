﻿using Convin_Demo.Models;

namespace Convin_Demo.ConvinBL
{
    public interface IUserService
    {
        Task<bool> CreateUser(CreateUserDto userDto);
        Task<User> GetUserById(int id);

    }
}