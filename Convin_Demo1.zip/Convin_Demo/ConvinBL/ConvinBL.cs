﻿using Convin_Demo.ConvinDAL;
using Convin_Demo.Models;

namespace Convin_Demo.ConvinBL
{
    public class ConvinBL : IUserService
    {
        private IUserRepository _userRepository; 

         ConvinBL(IConfiguration configuration, IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<bool> CreateUser(CreateUserDto userDto)
        {

        }

        public async Task<User> GetUserById(int id)
        {
            return await _userRepository.GetUserById(id);
        }
    }
}
