﻿using Convin_Demo.Models;
using System.Data;
using System.Data.SqlClient;

namespace Convin_Demo.ConvinDAL
{
    public class ConvinDAL
    {
        private readonly string _connectionString;

         ConvinDAL(IConfiguration configuration, IUserRepository userRepository)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<bool> AddUser(User user)
        {
            using SqlConnection connection = new(_connectionString);
            using SqlCommand command = new("CreateUser", connection);
            command.CommandType = CommandType.StoredProcedure;            
            connection.Open();
            var result = await command.ExecuteNonQueryAsync();
            return result > 0;
        }
        
        public async Task<User> GetUserById(int id)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetUserById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@UserId", id);

                    connection.Open();
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.Read())
                        {
                            return new User
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("UserId")),
                                Name = reader.GetString(reader.GetOrdinal("Name")),
                                Email = reader.GetString(reader.GetOrdinal("Email")),
                                Mobile = reader.GetString(reader.GetOrdinal("Mobile"))
                            };
                        }
                    }
                }
            }
            return null;
        }
    }
}
