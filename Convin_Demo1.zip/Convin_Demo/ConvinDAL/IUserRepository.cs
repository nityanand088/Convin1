﻿using Convin_Demo.Models;

namespace Convin_Demo.ConvinDAL
{
    internal interface IUserRepository
    {
        Task<bool> AddUser(User user);
        Task<User> GetUserById(int id);

    }
}